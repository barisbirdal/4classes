#include <iostream>
#include "nonCircularSinglyLinkedList.h"
#include "circularSinglyLinkedList.h"
#include "nonCircularDoublyLinkedList.h"
#include "circularDoublyLinkedList.h"

int main() {
    // Non-circular singly linked list
    nonCircularSinglyLinkedList ncSinglyList;
    ncSinglyList.addNode("dog");
    ncSinglyList.addNode("cat");
    ncSinglyList.addNode("fish");
    std::cout << "Non-Circular Singly Linked List: ";
    ncSinglyList.printList();

    // Circular singly linked list
    circularSinglyLinkedList cSinglyList;
    cSinglyList.addNode("grape");
    cSinglyList.addNode("banana");
    cSinglyList.addNode("peach");
    std::cout << "Circular Singly Linked List: ";
    cSinglyList.printList();

    // Non-circular doubly linked list
    nonCircularDoublyLinkedList ncDoublyList;
    ncDoublyList.addNode("sibel");
    ncDoublyList.addNode("ece");
    ncDoublyList.addNode("baris");
    std::cout << "Non-Circular Doubly Linked List: ";
    ncDoublyList.printList();

    // Circular doubly linked list
    circularDoublyLinkedList cDoublyList;
    cDoublyList.addNode("cok");
    cDoublyList.addNode("seviyorum");
    cDoublyList.addNode("annemi");
    std::cout << "Circular Doubly Linked List: ";
    cDoublyList.printList();
	std::cin.get();

    return 0;
}
