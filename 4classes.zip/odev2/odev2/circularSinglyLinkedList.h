#ifndef CIRCULARSINGLYLINKEDLIST_H
#define CIRCULARSINGLYLINKEDLIST_H

#include <string>

struct CircularSinglyNode {
    std::string info;
    CircularSinglyNode* next;
    CircularSinglyNode(std::string value) : info(value), next(nullptr) {}
};

class circularSinglyLinkedList {
private:
    CircularSinglyNode* head;
public:
    circularSinglyLinkedList();
    bool addNode(std::string n);
    bool deleteNode(std::string n);
    void printList() const;
    bool searchList(std::string n) const;
    void deleteList();
    ~circularSinglyLinkedList();
};

#endif
