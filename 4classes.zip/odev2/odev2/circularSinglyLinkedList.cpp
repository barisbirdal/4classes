#include "circularSinglyLinkedList.h"
#include <iostream>

circularSinglyLinkedList::circularSinglyLinkedList() : head(nullptr) {}

bool circularSinglyLinkedList::addNode(std::string n) {
    if (searchList(n)) return false;
    CircularSinglyNode* newNode = new CircularSinglyNode(n);
    if (!head) {
        head = newNode;
        head->next = head;
    } else if (head->info > n) {
        CircularSinglyNode* current = head;
        while (current->next != head) {
            current = current->next;
        }
        newNode->next = head;
        current->next = newNode;
        head = newNode;
    } else {
        CircularSinglyNode* current = head;
        while (current->next != head && current->next->info < n) {
            current = current->next;
        }
        newNode->next = current->next;
        current->next = newNode;
    }
    return true;
}

bool circularSinglyLinkedList::deleteNode(std::string n) {
    if (!head) return false;
    if (head->info == n) {
        if (head->next == head) {
            delete head;
            head = nullptr;
            return true;
        }
        CircularSinglyNode* current = head;
        while (current->next != head) {
            current = current->next;
        }
        CircularSinglyNode* temp = head;
        current->next = head->next;
        head = head->next;
        delete temp;
        return true;
    }
    CircularSinglyNode* current = head;
    while (current->next != head && current->next->info != n) {
        current = current->next;
    }
    if (current->next == head) return false;
    CircularSinglyNode* temp = current->next;
    current->next = current->next->next;
    delete temp;
    return true;
}

void circularSinglyLinkedList::printList() const {
    if (!head) return;
    CircularSinglyNode* current = head;
    do {
        std::cout << current->info << " ";
        current = current->next;
    } while (current != head);
    std::cout << std::endl;
}

bool circularSinglyLinkedList::searchList(std::string n) const {
    if (!head) return false;
    CircularSinglyNode* current = head;
    do {
        if (current->info == n) return true;
        current = current->next;
    } while (current != head);
    return false;
}

void circularSinglyLinkedList::deleteList() {
    if (!head) return;
    CircularSinglyNode* current = head->next;
    while (current != head) {
        CircularSinglyNode* next = current->next;
        delete current;
        current = next;
    }
    delete head;
    head = nullptr;
}

circularSinglyLinkedList::~circularSinglyLinkedList() {
    deleteList();
}
