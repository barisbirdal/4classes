#include "nonCircularDoublyLinkedList.h"
#include <iostream>

nonCircularDoublyLinkedList::nonCircularDoublyLinkedList() : head(nullptr) {}

bool nonCircularDoublyLinkedList::addNode(std::string n) {
    if (searchList(n)) return false;
    NonCircularDoublyNode* newNode = new NonCircularDoublyNode(n);
    if (!head || head->info > n) {
        newNode->next = head;
        if (head) head->prev = newNode;
        head = newNode;
        return true;
    }
    NonCircularDoublyNode* current = head;
    while (current->next && current->next->info < n) {
        current = current->next;
    }
    newNode->next = current->next;
    if (current->next) current->next->prev = newNode;
    newNode->prev = current;
    current->next = newNode;
    return true;
}

bool nonCircularDoublyLinkedList::deleteNode(std::string n) {
    if (!head) return false;
    if (head->info == n) {
        NonCircularDoublyNode* temp = head;
        head = head->next;
        if (head) head->prev = nullptr;
        delete temp;
        return true;
    }
    NonCircularDoublyNode* current = head;
    while (current->next && current->next->info != n) {
        current = current->next;
    }
    if (!current->next) return false;
    NonCircularDoublyNode* temp = current->next;
    current->next = current->next->next;
    if (current->next) current->next->prev = current;
    delete temp;
    return true;
}

void nonCircularDoublyLinkedList::printList() const {
    NonCircularDoublyNode* current = head;
    while (current) {
        std::cout << current->info << " ";
        current = current->next;
    }
    std::cout << std::endl;
}

bool nonCircularDoublyLinkedList::searchList(std::string n) const {
    NonCircularDoublyNode* current = head;
    while (current) {
        if (current->info == n) return true;
        current = current->next;
    }
    return false;
}

void nonCircularDoublyLinkedList::deleteList() {
    NonCircularDoublyNode* current = head;
    while (current) {
        NonCircularDoublyNode* next = current->next;
        delete current;
        current = next;
    }
    head = nullptr;
}

nonCircularDoublyLinkedList::~nonCircularDoublyLinkedList() {
    deleteList();
}
