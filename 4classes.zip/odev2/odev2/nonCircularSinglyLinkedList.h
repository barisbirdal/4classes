#ifndef NONCIRCULARSINGLYLINKEDLIST_H
#define NONCIRCULARSINGLYLINKEDLIST_H

#include <string>

struct NonCircularSinglyNode {
    std::string info;
    NonCircularSinglyNode* next;
    NonCircularSinglyNode(std::string value) : info(value), next(nullptr) {}
};

class nonCircularSinglyLinkedList {
private:
    NonCircularSinglyNode* head;
public:
    nonCircularSinglyLinkedList();
    bool addNode(std::string n);
    bool deleteNode(std::string n);
    void printList() const;
    bool searchList(std::string n) const;
    void deleteList();
    ~nonCircularSinglyLinkedList();
};

#endif
