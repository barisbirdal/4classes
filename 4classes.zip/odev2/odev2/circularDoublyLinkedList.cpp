#include "circularDoublyLinkedList.h"
#include <iostream>

circularDoublyLinkedList::circularDoublyLinkedList() : head(nullptr) {}

bool circularDoublyLinkedList::addNode(std::string n) {
    if (searchList(n)) return false;
    CircularDoublyNode* newNode = new CircularDoublyNode(n);
    if (!head) {
        head = newNode;
        head->next = head;
        head->prev = head;
    } else if (head->info > n) {
        CircularDoublyNode* current = head;
        while (current->next != head) {
            current = current->next;
        }
        newNode->next = head;
        newNode->prev = current;
        current->next = newNode;
        head->prev = newNode;
        head = newNode;
    } else {
        CircularDoublyNode* current = head;
        while (current->next != head && current->next->info < n) {
            current = current->next;
        }
        newNode->next = current->next;
        newNode->prev = current;
        current->next->prev = newNode;
        current->next = newNode;
    }
    return true;
}

bool circularDoublyLinkedList::deleteNode(std::string n) {
    if (!head) return false;
    if (head->info == n) {
        if (head->next == head) {
            delete head;
            head = nullptr;
            return true;
        }
        CircularDoublyNode* current = head;
        while (current->next != head) {
            current = current->next;
        }
        CircularDoublyNode* temp = head;
        current->next = head->next;
        head->next->prev = current;
        head = head->next;
        delete temp;
        return true;
    }
    CircularDoublyNode* current = head;
    while (current->next != head && current->next->info != n) {
        current = current->next;
    }
    if (current->next == head) return false;
    CircularDoublyNode* temp = current->next;
    current->next = current->next->next;
    current->next->prev = current;
    delete temp;
    return true;
}

void circularDoublyLinkedList::printList() const {
    if (!head) return;
    CircularDoublyNode* current = head;
    do {
        std::cout << current->info << " ";
        current = current->next;
    } while (current != head);
    std::cout << std::endl;
}

bool circularDoublyLinkedList::searchList(std::string n) const {
    if (!head) return false;
    CircularDoublyNode* current = head;
    do {
        if (current->info == n) return true;
        current = current->next;
    } while (current != head);
    return false;
}

void circularDoublyLinkedList::deleteList() {
    if (!head) return;
    CircularDoublyNode* current = head->next;
    while (current != head) {
        CircularDoublyNode* next = current->next;
        delete current;
        current = next;
    }
    delete head;
    head = nullptr;
}

circularDoublyLinkedList::~circularDoublyLinkedList() {
    deleteList();
}
