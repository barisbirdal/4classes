#ifndef CIRCULARDOBLYLINKEDLIST_H
#define CIRCULARDOBLYLINKEDLIST_H

#include <string>

struct CircularDoublyNode {
    std::string info;
    CircularDoublyNode* next;
    CircularDoublyNode* prev;
    CircularDoublyNode(std::string value) : info(value), next(nullptr), prev(nullptr) {}
};

class circularDoublyLinkedList {
private:
    CircularDoublyNode* head;
public:
    circularDoublyLinkedList();
    bool addNode(std::string n);
    bool deleteNode(std::string n);
    void printList() const;
    bool searchList(std::string n) const;
    void deleteList();
    ~circularDoublyLinkedList();
};

#endif
