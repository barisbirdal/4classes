#ifndef NONCIRCULARDOBLYLINKEDLIST_H
#define NONCIRCULARDOBLYLINKEDLIST_H

#include <string>

struct NonCircularDoublyNode {
    std::string info;
    NonCircularDoublyNode* next;
    NonCircularDoublyNode* prev;
    NonCircularDoublyNode(std::string value) : info(value), next(nullptr), prev(nullptr) {}
};

class nonCircularDoublyLinkedList {
private:
    NonCircularDoublyNode* head;
public:
    nonCircularDoublyLinkedList();
    bool addNode(std::string n);
    bool deleteNode(std::string n);
    void printList() const;
    bool searchList(std::string n) const;
    void deleteList();
    ~nonCircularDoublyLinkedList();
};

#endif
